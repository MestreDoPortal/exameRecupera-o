import 'package:app_exame/text.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        drawer: Drawer(
          child: ListView(
            children: <Widget>[
              const DrawerHeader(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: NetworkImage(
                        'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUSExMWFhUXGBUYFxgYFxcWGxgXFxUXFhUXHRgaHSggGBolHRUVITEhJSkvLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy8lICUtLS0tNjAtLS0tNS8tLS0tLS0tLS0tNS0vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAJ8BPgMBIgACEQEDEQH/xAAbAAADAQEBAQEAAAAAAAAAAAAEBQYDAgEAB//EAEcQAAEBBQQGBwYEBAUCBwAAAAECAAMEESEFEjFBUWFxgZGhBiIyscHR8BNCUmKS4TNygqIUI7LxFRZDwtJU4iREU2OTo7P/xAAaAQADAQEBAQAAAAAAAAAAAAADBAUCAQAG/8QAMREAAgIBAwIEAwkAAwEAAAAAAQIAAxEEITESQRMiMlFhgZEUQnGhscHR4fAFUvEz/9oADAMBAAIRAxEAPwD8TDfSbq63oSzHROThtEKb643lxu9LLPTYCbfF1JuEGTFw74ZiYYoCWc7GdBIMxQGNhydhY2HsxL78FQKvgUQFbp0OzFuFQK0GSklJGIIII3Fs4ao78R1dMzDIELuB8K0eacL33YJTkpJBDGww0s2MOHgAVRXur8Dp2sY9NoyOYoamqPwk+h3Ju3zik2YPIBSDdUPWlu0w/Bp91ZG8oUHqGJPKF03uOv8Au3b1zLDsqE0n1mMGPjISTYQ4FXaj1TVKvhVp2HA/ZlScbiE6D6TFT13Jvkhmz+ENZiRTRQ7iy8upGTa6siB8MgzpKJjaOYr3TYhwiYLeOU8RVjYN1WWR7mXsbaPJXwYdAOpuzqI5j/taisaEmN3iwNiQ3aScxMbUmfdNqmxIWm7xDRdXdgER8L0pJS2Ifrb2S2y5kUp0JTz63i1takHN4BpPi05armbxSsgZDYKDuY+muzicsTqXaS8WistgbNaZD1hkxz13NXrH13MO/RWTVUaSrkgN1jIWHmQN5b5y5mdjPIOA6vWoJXlq+FOQ1k5DY3XsCye6nGByYD7O4kvCNSBpVmdie8hsYeGO84sesF6q9KSR1UJ0Ad+knMlm9l2ZMzIp3tg29IyYraekYEwhYIITeOJw82FfOmpYiEOMtnrQ2cPY5XVXVSMVH1UsBLxnJkm2zp8zSfgbLU9VIUAqVHADMksVGRCUoLpxRPvPMCvZoT3s7jUAIuJFx0MveWRmryyzaaj1ToMNHmztVnVxF0LWtluOw/mJolYFBxYEoJZ/C2I8eTKU9UYqNANpNA3jxy7d0HXVpy3DFXc1BKyZQW9R5V3MSJhCamgbx4AKBioyJ0mugeflxYBczqDHAVeIwvUdzMXim4k24dN6XUsW6EJ5hMgQeTeybRQbkhu9OJ0Gdl1qb0O25Qsht0PAcQzSKrTuSOZl7JvvZsY7G9i3cOlVMDrZgUCeADcRQXOhuChn67IViBvDYrgDmONObZOjRuDid6XHbMWOXtetMfMMR5hqyz+lbxKA7iUJiXWRXVSR8rwdZPMamQv7KUBMV9c2HcvFIMpTGaT6oWVt0zKMMIxReyHaVyoaHedeHeS+R4QDsCx1VbKHU20JNJurEtol/ZpUOqe0dEyz1alDRrw2MxgLcWjqqEwMiJjhOn6SGntU9RyJSFqXDzCXULCJWm6ajLSNmpvnthlAJFUn1uZdYtrujgbm03k8cUbxLW17ZqQsDCR2EEbqHaGFZqezCY8HwzkSBiLIBInMJnUgTIGdM2mYuz5THBv3V30cQqo4NLW70aCSaMl4gBjaW12eXvPzuzBek7XRQoknMfArwLB2nZhQqRFRhrGja1XaUIi4EBElgk3pmahSQlqk2LtaX7v2b0yUjsrzGiekMq1pU5HH+3hvB6+eZKByARIzEhXvG5jId1XZ3eu9t4yz1O1SUMcxUHWDmGIg3M/WTYewEZjNdWdo5s1+f5YPZTOQ0BXaa1sWDqRt9cmjoKHNG/R+izu8ATiBI7qd0m+f1pJ2Xk7QesboTMmrXh7ilL+EE7/d5kNFxyzcu5VLfpPS+E9we8ZnYKDnPg0BaEKQWLon2HVzCaZutMiTK3Uqn0WH/h+qVTE5yAzOk+tLNIl1OjE2ZZIV/NeEpdig0qOhIz24BrXjBVyYC2nJmFgWKp4SaBCKqUcB60MVHp9ofZon7NJmTmpWk68gMuJLSNiKJcoAQgYJGA0qJzVrZnAWe5KEBAVeremKbWVbUEed/kP5k3UJ0+VRFNm2MTk1NB2TdEyGo7JscSBIozcwaRk0+3VWWAsBt7xBqR3kqLLCjeKZDIDNgrUUlAwFMB7qfM62fWtGhAxAnSZMpnQMzsAJ1ND2zartJ63WIwScB+gGf1kEaCxNIllpHtJ9ukDHOMmLolK3xJTgMVGiRvNAwpfQkPVY9uvJMylHLrL3SGtgI203r40N1I3BOyQkD+UT2sOqHDqpE1msj2q5q+DZidIm31OlqKxc6PHq+g/eE2xbL98AXpDp0Oy7SAmWpLsUG1Uy08+eEzCRdBxzJ2nNjS4UszO7VqAyYtzZZlOVNJoPW1qiVkwqotY4iFEKdG9tFQwGPAeqM9VDgUEydXnlubJ5Zi5TUAga6Fnq6lE952iJY1S72xKdTOhATohJVrwHFsXsGhP4jwflR1jxwDENWZ0bRMpLau4RZFEmWujFrign8N2BrV1j5MG+fqVVSid/gw2CrzCDqPE1S7QrOTemz1YiRYZLtQy8WIcvSGdQVPtYuD9Jw+IPSciZ+zUGKcvyPvViHcTPtJB5HixKIJK+woT+FckncrA75McUFd0ORBeJn1DEKsy0ZYTGyo+k1aos59Cvuq9AB0pkDwVTm0S8hSgyUkpOg04HMbGMhVnSDqV54ji3TQHjVWtavZtxLeL6GIIvOHyFD4VTQf8AieLTNodG1iYUjemRYuCilpl20cx9ubNC/eFM8dYr9wwvBsXYnIjY1WnfkSLNjPEG8jEcdks9lW4EFfoE3V/AaA/kOR+XvalflZbB65VLrAKYT6Xq5nvFqB8pxJxEOtJpMEZYKHrVyZ9YlvvHRmCZZ3ZV2pPVJ10OttQpKhdeg6l+8Np94ba62zf2UodYddJ99Pjr21aNqtGV/CP13jhp+l9HemaFiSpA5lM5fqSesnbUa2oIt4l4mZAUDgQeYOBb8Vh3ciCDUZihHiGs7BtVaUmfWAqRpGZ1K15tA1FBUZWbbT58yTa2LISudwzOjBQ3eIo0fEQakqvSqMdYzb9Ajbr5N5J35g6/Nkb0kmTwXpe9gob89/Fp5sK8yhpmOMGIErErixedqqNKZ5jxGcm5EKXagJzGKTkQcJc+bUJslK0G7jiPGmTDw0Ifw1bUnXmN/fJlDcN8R9XXkRrZaXYdGaSV5HIDNqzoyJAlpWz4c4NUWe9CJDi0e5yjhl5zmTNd5lIHed22gFQUWjulLt2SQ7wA55tTxry+S0kqFUt4UzljU5CszuEzubel6i5dvfP1mtEnSMk8CT0PAAzWvsJpLNavgGrSchtYhKVLN9WVEgUA0ADIBmxg/aqCUCSE0SNWZOs1J2saYZ2ikr0vpnu7RawHJMcYjvzFFnWQp4qQB0nX9msLIs1CCB21aE1ltOAYGFKl0wToFByZ0mIS6RdSOsafZsWoz7SZqck4AjN9FpdJmogahXdrLS9sdJyJgG6NxUePVTzZfbMcVKIBnKk+/Y0+9d3jmo8vMs1ToWbHicDt2gl0O2TB7RtRbwm7OZxMypRGtRM5asAyt1Z5WfiOJrJKQMSpWAGzi1EmywBN6boxCRidifE8W8iKi6EhKPhxnoKj7x5DIBr2m0h2AEBbWqjAiJDkzuugVKHvhNE/kHu/nNdmJ2h7DzUa6Ei8eOHNmV1cqCg3Absm9dqXlM8WtV6MgRHpTuYTZvRta+w7Sn5lkE85AcGbvOiLpIvP396WSTOW/AMlVFvRi8ubKngPGTARD0qqQt5reKMvpB8WYXR2N97Ew9lCekZjCMiXCDccJE9Q9orlQNPWg/AM13QfnN5X0Jw3tzGxagJFd0fCgBI3yx3ssdQS3tUI6vxqN1PE4nUJnUztemWsbxG3Ul9gPpBo20CqgKiNfVH0jzYBDl4sySkk6AGel1Duu0S+VoHUQP8Acrkw0TbK5XUydp+F2LnGVVbyW2ac8nAi4Y52GYN/l9Sav1pdZ3SoBX01Vyb6cOigBVrkB3zLAKUo4AluTBPDiJbfs2Nl/wDmmTCdDH1tiZO4gMQl/pDEDo4+ySVflkr+lRbFcEUG6ohJ0KISeBLdrOoxuP0nS1Lbhv1naHqNjEuruSh3Ng7caSk70+bFOoKfvAfqSfGbMozewgnZe5P6/wBxnBxbxIu0Uj4VAKSdxoxaXDlfuqdHSnrp+kmY3FgHNlqxCky09b/aDLex0PBLEpLT/wDIkciQxNjvxE3cLwYygoVaRJCkvBoBA/auXIln0F7OX8xy8SfiEwO4g8WSwzh6Ne9BZ1B3x7pHray92SOZqrVVg75h6IZwrMb6Ftf8tIUCUrGFJ+bbwvtTglfhxY9yh5nd3qR5tOssZeGlAX0uNjI+O6MPh2UTGqSp7mBRBPXMzcWjT1VSO0ESLfqDiz1LGXFPgyyPdvXZIBnqM/NgjUltto0l/SvuPjPzpUW5UZLFxXxDDhiObMIBwQQU9YGY6uYIrhmzuJeldFoE9C0hadxIZcAh2qZc3Cc3aikH9NUHg0/V0hgcjEo6fVDhfpM3UQt0u6rcclDIsepIeCYx0MRDJcvk3SrYCJEbx5SbsWUt11k9dGkVlt0N8xqqiJUS9T8DC7FgbwOTaRVnics9PrPW3sKqk07wxLkk4t8+9biwk8TxsbqLAzOEhusJjUdrav0yM9jM3DqYnmJcsG8XCzUrb4sVKOr5xY35beJ3NZsL/BGRkKq6u7FXhzZ7/A3VkDCTbKh7okMe5ml0vRN/aQPTFDizABdnLSdO3QNTLImCkWpVGQCBtLKrReDJnNNpz6jDU2uW3i729wU9Fhkv1ElRxGA1/Zif4BRqvqJ+ahOwY75Nw9uCgKz+RIT+5Uz+0Nc02jHqMa6k7bmLnkMBV4q6NGbeJfDB2mWvE+Q5szhbOCje9kn8zxSleIHJm0MiVEpRtCAkcMSz6acLxAX3qJLu4NajORmc6kneWbWbYwxWi9vlXS1RBwS1VvJ+lPk2kRCEYlJ+kMYW9JwJF1NwcYMmVWIkeQqwT6HdpBBSqeVJDW1DEQxx9mDrlNlb++KJdnck+DOVMzcmJnU0oN4jiUyM3Toyl7wnzMgyaIglK7awnUOseXV5s+jPafAr6ZeDJIt0+OF1O0oH9RanUPiJJt1tIORAVuHKKpdhavieG/LYgdXjNllpPniz1101qAA1ABjH1lqUavUn9d/k7vFuF2ChNVvP2h3+56QeTMZVfjA/aVbiIFoQMVjdMtx7V0MidtWYxNmoB6qnR2vkHkGCXZy8lu/0qR/ybxb2AhVsXG5I/L9BMHsZqkNwYRcYGPc9H3rzsgr/AC9buLGI6IPTjJP5lIHK9Ngvbaf8JtbKB3/WMnNrqOLlB+rxJZm4t0ykXRloKr4+lQkydxHuc0E7SfAhjnNoOcnSeKj3qbR8NvjJjdSn04hwTAvfxIVA1pBcn/6ZT3tseiMC8/DfvXJ0KCXqRu6qubDurRTklA/T5ljXMerJUv0oPgwWqx6Mj5zH2m5e8w/yA9Bm6iHKxrK3auBEubEo6KRKavEzHyi/+5BYxxaK9IO5Se4syho5eJJH1HvT4tg2XrtkH5fxAWanq9Q+n9xAfYOzI3ir4aj+pukx6x+ElLsaZAq4yMmq/wDFpiSyFDQoA97cB3CLxcOwdKZoP7JNnxz99c/P/wAgx0Hg4+UUQDx8vtKK9pC/OTF+3AMlIKdaf+J+zOIazYcVSFj9QV3gsUINzpntn4Fl31CZ9M2iMfvCLYaNWOwoK1CivpOO6bZvotaqlJ3055M5/hEe7cGwAHjKbcLg73auq2qmeM5sDxFznEeTq46pPrfJzNdAmeYYp0ErBTic0mh2yNQeRY55Yjs5y3jvbP8AwaUiF7JmfAg03MOxlaOVWFfeKXkAkGYB9eLMIF8RgTTPzZimzycesdIpx0sa4ggkTInsBAaFq9L1HIMvabWllw4zBXbsKM5AK0ih8ixiIUHbyPk2geEaN0g2zqZz4tKbTsDgjMZNpO4nrhwUsT7Gs9LauQ2wDN06JQIs1hzBPZZtitySzEpbB8CxW0yieWw5ip7DZcdJ35MCuGlhTZjxxZq8cjMk6hRuQ7Hw85t5cqY2tuJOP3O1uYaGE6CbUTyAvaw2a7PMpCQHM8GdqsP3oVtaMYil4RhPvkDub5KSeypJ1Tl3sYuyJ0K6aMuDfO7KQPenyZ9LRiI3alQNjMA+eJoEqnsPcwkU+Pvrn8qZHirAbps79lISvyTokJcDjvbFcK6zu8JdxkxEsAPH0ku/UEjaTy4k+4gJ1yvK4nwbB5ExGJfEbTe5GbUbyEc6TuIDCPXMPmkq2qPhJmVuT/r+X8yFcljfek3FWnSSgF/t+3Jlzt4h4ZJcm98rsPO4eDVynjlPZdIG1IVzU2T+1jKQXIaBLuDMLcQMKv5xQ1KpyT/vrJaK6MRTwUvhJyWQ7A/SSk8mA/yKRV9Eu0akJU8PO6ObUUVGE4rPraplj56NI33Pux1ttI5x+A/mEW9l9I+pi8WLZzvt+3enWpDtJ3OyVc2IcWlAuvwoFMxgbwUfqWkq5ty8iAPhPrUwr6OdAVdoO5Xm2+hT6sn5w4utPeGxHSsn/wAqkjK88UrwYU9LXgwcOhuZc8tFx/6Q3Ffmwb20XPwEby2wlP8Aj/c2oc79Mzdey+Dv82KT7LIENs76NOv+sB1B0VHkosWOj0Mir2KWka0Jdf8A6LDdLqvI/KEYdXBzBnaUZEDd5hi3CFHBSefg3xiLLc++9fEZJrzKUp4KLcL6Yuk0cQSNReqUv9gl3tnxgfSpMydHYedhGzlD3Kuy6O+ZZlCwb9WKd5r4ANLJ6VxquwlKB/7bkJH1EEji3xthS6RBQv8AMq+eAJLc6HbsB+cAdLvuZZBbtH4j5yJYgKCiNyZltE27CJ99SvypI/qIaPdw0O87Iep/KFEcFDxY5z0fXi7Wk6ilTtXFUxzYbUp99j+kIukwdhKx1b7g1DtRHzEDum3Y6SOsAjvPcQ0y7seIl2Jb/acnYUeTFOIMIPXS9UdFwuk8VC8fpDBaijsc/OMJpbD6VH0lQ5tMLolLsnIdafNuIu0FoE1OwBqSVc8Oc9TLnMO9WJABCT7qRKe04q3kt4LPeO6pKk7CR3MDwkzzGW0bATw9J1XgkOQNGbEObYfKMroSdFJ8Mtpowb2Z7ZB/MlKjxIm3z2IduU9YhM/dEgeAw2/3bT1oBsP3ildNnidOSY8d2mU9ognVQDzLHwlppViQe9ohNo3+ymmnBmcAkq60pAYqJujiWkamjPwn0um07IvmlgXyTgCW7dLVoCeZZI5tQDqgz2ef92Nd2gcAJHTi0kjpO5jfgsBxHrs6W1BZa5VM4zbdMQxK7gRmKtWYWVMLEE5FvA+nMMG9ibpYdt6zSVnM+Uo5ifJvFPEDybx69SqoxYFUjgQDrp9mSa/B8u8YVM87Qh5acs+DZvo5UppM9UqjzDK49Kk4hh4W0UkyJkeDO6a7q9UDdUAMiGrtpYEymYOdD/ZundsBXuy3T5fdsnyEnrEDb562+QVYJUQNA6vc1qsKRIV9w4hqXypTupljOoppljybFUe6zkTqmOZ8m6dWao1rPTnxYG0XKgZLRe1iiuIx3gsVSucRLxGI4MIeWkj4P3fZhHtpucwobDPvky55BE9n2g1KdqPNAPcGEfWc/wDlO1Q7jXkx1VPeeCs3MYPYqHV/qgfmT5AhhjCBf4bx2vUFJnwFWVPoCXbVuSD3nyZc/W7TggH8xB5GnJmFz2M6dGrdo6iYR6nJXPzZXEO15iW37hgTbMQn8MqSNCVGX0ijYr6WRA7bt08Hzu5HigpLMKW9oM6Fh3hCxrHLwYZaXeZ9cG8Nvwi/xYVaDpdvL3JV3vbMu4BfZfLT+YhMvrQB+5jq47gzw0zjmZvkOdCvW9hlOXRwHrixq7BdETS/eS0+zDwcXaywv+DOv+rG9yod6mIMEbD8oQJjviTp6SRGHtFS0AyHABsk2gvGQ2yHfJs0QobdMOjPmWCqXclv0lfwa/YTt3Hr0pGxKT4MU7tFZpeWdQJHINw6ujAcvNjHZOF3j5DFjKW94ZNCH4X9p05iVH/TB1qF7+olmkLEPcuqPl6o5SbhxBKAvPCHadKjdnsSJqUxrh6jB2hTw/Erqp+kG8d5Gxss+OY6n/GADcTdyl8r3j9RLM4eAWO09ltMmwcQ7xVVvQ6ToT1eSaneWJS6h04ArOlVJ7sWC1hPEar0NY7Q5whI/wBaf6h4TZzAlQweL3Xj4tOItNKeyOAHeW+X0hljUaJ+LLOrt2h20yAYAl0i0VJGBV+a6O8sotS0lqxW7djSVpJ4DzaEtG1lLJukpBwEzQaNJ2srEOp5MzpmpRkkbTp1Y6m7Xo1HmMXbSpyTKyKteHTP/wASm9pSCtW6U7u4MC6eulG8EPFD43kkz2CpP072ToU5dYC+rSRJO5Oe08m3h3qnqqmmJ2CpJ1SYrBRxA16YFsVj5x2I8ATAA1nrHnTk2jp+t4QVEnRXBg4ODLwzlJAw2ebbRMUl3QHBpep32EqUolZ6V3MprNc0njJmDsEnCWtpKx7ee3uoCR4eAZi9thSlBANSakYD1pb5u+uwOeobQ76ZyZVqiwJJGqfgG5cxwBkc2QOosKUADSbELne2NLs1ByYv9lA2MoUxFZtnELBZfCLodQJ5SYNEbiJ1TUbMwyD6liYIafc47Rkl2Z0YWLURMZ97awkfSY/swVoRE64sul7F8TvQwO4mCbTUjqmqdGMtgNA3kSl2sA3EmeBBKD4ieqjfIcpeCmLYuXBBLpXvdk6FjDjhw0NVp1hTEUuVGBxzM3Uah0Ze0eu9TxF4HemYI2sxcvnS6peoB+U0+k1HHcyB5EqTNKxfSOXiGGMO7VV2ZH4SZHccDyb6LS6lW7z5/Uop5/qXsJFKTQLQf1Nu9iCRU8FBvztLx4gymdhofuzKEtiUwokUptaj0Z3EQ8Q17do+inc8Z8/uyWKhgfflv820d2uDm3q41JxkeTMLW4nk1VfeJYqAeATSpW6fgWTRPth74O2R/qDVMb7EyuFSFSrWVdUsmURSl/K8HzCv1CShxZivrMeS6mTEQ8eZoSf0jwYB7EHQU7CpPiWo3zh0vNTpXzfzEcQLw4Hay6Nsx8gXroWj40G8niJy3s2pIjIWtx5YheRatJ315/ZhlRi8pcvEMc+XpTyBYN4UHIcGLknvMGpR2mH+JLBngdw8G1HSB98at5n3hslIRkebZKhhk3um77rTnRUeROnThRx50Y6Hg54CfIcS3pjHSfmOr/kacA3BtJ4rsC4NWP1GvCTe8i8nJldErSNUQyEfiLkfhSJqO7HjJtU2kE0dpS7HxGSl+SfVWSOHRJx4VZg5ghnLeZ8hRiAk/AR6pXc4UQt1EIKpyU8VpMyfEsycxbzBICe/gJni2MDCg7NJ6o4f3Z3Cx8O5yCyNVOGDCe5BsN5UTQ9Iy28zhbPerqEqOs05CZ5tq/g1IHWkNtBwxLdxnS5+tJSkpdI1SHIYtMRlrpxJLw6VGQ3DPky/iP8AewBNdCqPOAPwMPfPxkSrYwL16ZynInBImpR2AVZcuOePJyIQgYnAAazidjZiMDsSRNJIqrF4saB8CfVW746qIm5XtG6njt32xeXkgGcvzS7hxYCItFS+0ZAYAYAaNAZcm+qYFBnnvUfMyagsXo2p4QSKaVUG7M7hLWw3vLRZyOTAoVKlnqjefvQDW1x0fsFV2ZEkntE4kYyE8teexn3RzomgSMpyrMiQGsJ8TM62bWzEIdJu5DRSe0+XFljqN+lYs2pOcJJi0VkD2TpOGjvOga2n3sO7Sbz1d4/Ckg88BuntDdW5bmKRQfCKCewYlp0P1LVU7dWrawbXKjaVdFT08yjXaoCaAITkkZ6zpLd2e9N0rzV1U7PePCm9kCU3jfeG67FEjNWpI8cmYw9oVvCkqJGgZBoWrbAOOZWUDGBKyxHZnItYQ8IFAKz8Wl+j8elLu8oTUrA6GrrLehSJhvkbS1uoCHYSN/yDOCTjEXWin2SCkYnFo6Oi1IUlejHWMw1b0hiLq0Twl4tN9Jol0sC4JUkdrCoJ6sEZzN6UnpGRzBVxxdqDxBmhVR4g6xhuZh/iSVSJGOBFDrG3vaPh48OyUPJl2TWWKTkseIzY926IF2c0KqhY0juOos8+nHeGfBG/MroNPvO1Xhoz4HwZ45dofCRoscQQ359ZtoqSqRooY6/mHrXpa0sm1QZXq682WsDId9xIWoRerIMCt+yFTvgSOrS0dGJKSbwkdIpxH9m/ZUIQ8TtaZ6QdGwQSOeHHEb5hqemtanBO6+/8yXdWeRPz51aqkiSpLT3eIbf2yFpmmZliMVDXdzGsS2MJa9jrdmgKdAOB2EUnsPBp15FqQoYpUM8K+O1vqdLeCNjJFtWeOZUBd6RSqdMvU27u3qEtPpjQ8rMJX8WCVHX8J18dLdO7XUglKxUYg48c2tU29oqtI6skfjK2F6Pv3if5Srw+GYPIsttCz3zqi3a0HSJy4Hzbmz7YMwXS5K0EyO44FnY6cPZXHyQsZhQqxi1oORgj846i6ZxjgyQfP16QrVgeB8GERaKnappKkKzkSNxGY1FquNi4V8OqAlXwqFNxaaj4ROFRon1huzDNVkMNxNrSyelszh5azt5R+7E/jQADtKcDulsYKJs12oXnawoaRiNoxG9hoiDUMKjUy5c0mYmCNFC28BeRtDoXncTZ5GFQwK3ZBwZg7tVQPWF7Xgd+R38W2/iXStG/q/bg2PDqbg4jGW5/uLnLg6ANrFoCR8x5MIFa21SvcwPFC8CV6goh6Hp0yGgNu6fgYCulliXuhui80nd9smXsvJ5Mo029PEafxM8ydQ8/7t4qLA26B4q8mVqiDLQPWJzbgKKqBlH1eOI19pJhcRGk5+Q2DNuHDi91lTCccpnwSNZbaGhKil5RwGPrY1K66PO0J9pGvgjMOkyW8P6ZyT+quplG1WNzOih38zSZvXpBCSdAFEjZOqjrxY1zY5B/mEJn7onM7QOsd5DMH9oJBuuEeyThPtPFDWrLdJvISmrmT5tqq1rDO201VjJ3MZ2TZyBKScMJyJGuXZTtxays1SEVNdZwn4n1RpJzFJdpvKoMhmryGvhpbx3bUzeWKAEAYAUpLfXW1DwjjeSLmNpx2n6BE28EIoZaA0B0gt4rJqym0LVUak7A0/FxnFh+RN5yqpUOTGEa/dlKLpUXpnfBAkK9WW7FtlJS4QC8qo1CPFRyGrE6mXwig6657eP5RkfzHRky+MiipUyamulkbLM75lPxugfEw15FqeG8s6gMJAYADIMY5f8ArwZWuLUuU5dVISKAUGGDaw7yZA3+XrW0yzfcxmm6WVnxxkA36T0bfSSEnRM7T6Dfl9kuxeSDhidgqRya2sGNqTP1MN8vr13BXtvM60eIs16Uvppn8JrsIx4jm0NHRVWprRibzxSDgoFO/I8ZHc0XaFE9oE1mKzFZSLa0VfvAp5ExB4x7nxbuy7WU5MhVJ904KHgRpDLS/pLd5cu5hf4iQKaYgg5gjKeg+AawKQy9Jitt3eXdpID12IlwTNPaGaToOrQW0sm2k3RKd73wcAZ0lqaVsC2y6VjJKqKzG2WY1MTaqQlRfuhIYPEY3Se9JyP2JX+zfcbjsf2Mk6o9fp5n6vYdtgYmjO02qDQ4FvxqyrZlKtD64tVQdrTGNGWbStWduJCs1bocSntSDmDdkQcUmoPnsaFtiy3Spgpu6qqT5p3GWpqZ1bEhJVQwlqXVi9iPiGI2+vJn9IrJuhiF+qUnfYz84jrCWianRmNE5jj/AMgAy5cV/pvgUkdk5jZPFOrDY1RGoU7VNJloIw+zcuIuHe9SKdzB95MgRr0E68dbfU6ZsrzPDUHHmGR7jkSVeFTvEzScFDNikWySAFG8Mp4jf4M3tLoqp2kvIR4mIcmpdmihtTiDrBO1pKKcyM0gpOaFY7viDPqzDcRmvw7eCP8Ae/tGqooGoPm3qbUUKYhkAf6aFu/4jSx01I7xlaisdqjAaihbB8+vYgFlRet9/EMYXCGAzzCHiEnCm2rCrcH+zfe1bkLbhdDyPpNgkf795mHrdBelhQtvrzR2ujyviGe2Oz1pb5L3RVh0Jnixzl3L14su7kx2gM86cuZmZqzFyiWchpz3MEp9d2tkp+VYsu0p1vXV8THbu1LlHXV0r947D7o2NiHxJnOes+qllztinazgMTRsrWWO8a+1swhrk10n1ixynwddqq9GSdvkwC3wc9UVeZnJOzSdbCB5MzLU1xV+P6RG+wv+EPeRRUSpR+7eJez6ysBgNLBA3jqbCMicssA2XvJOBFwoUdRnsbGzM/Q1Ng4VL+YcfcH+7YMmFT1jI4Cp8W7ePc9w1aGVsfq2gw+PN9Jq/f5T1nWWEvzM2yeLybxBYTmBNpJh6Fc2KgnlSplwV5cfRYhyuQZWwZEdrsxKuyIiilTyA4nyBaosOL7vENCQT6SNp7h92fWVEy4eLRtVVkGPBspD7Vi+vPX4sgtV7/NVoVX6hMd7a2rE9beyq1Xsyk/KOVPBt6erGIG5/LA3i6y9Ty597Dvl5t9FqrPe2KlY+satSVZKsadIeyLOYO0TIHEgSIOCknI93DQ06VNu4fSruLEZAeYlZnGRyI3fK9moXSfZrqknLSDrGB3Fm1mWndocM2QIXP8AlnA1TqVkd+B+zZuH/JsdAYYMn6mkWDMu1x0qTpkfWTZuLYUg0NMxkWQwsXNN07m5U9ybtSdJkhtOOGEpohQeJK3dfiRiRrGkcw07GDNOGhs3EcpCgoEghj3gD9JW7F14BNScAdY0FqlQ9phUNB39Pv8Az/MTObVW7M0qIbWJtRD78QC9p1stiZEnIsAtUsWbW5l/CUl06N5hsfhC4uG3jT92AWkhu0RJGxulKvYMQlX42MZXqXYzD2jeX28WlsiwSzLDAAza8319sZt7ebouncT/2Q=='),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    CircleAvatar(
                      radius: 40,
                      backgroundImage: NetworkImage(
                          'https://media.licdn.com/dms/image/v2/C4E03AQF7kyGADDrh3Q/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1637239987822?e=2147483647&v=beta&t=leCSqZzQ_-1jbaFi4VtapryKR7SThWzJBPQh7W5itMM'),
                    ),
                    SizedBox(height: 10),
                    Text('John Doe', style: TextStyle(color: Colors.white)),
                    SizedBox(height: 10),
                  ],
                ),
              ),
              ListTile(
                leading: const Icon(Icons.home),
                title: const Text('Home'),
                onTap: () {
                  // Handle the tap if needed
                },
              ),
              ListTile(
                leading: const Icon(Icons.info),
                title: const Text('About'),
                onTap: () {
                  // Handle the tap if needed
                },
              ),
              ListTile(
                leading: const Icon(Icons.settings),
                title: const Text('Settings'),
                onTap: (){

                },
              ),
            ],
          ),
        ),
      appBar: AppBar(
         title: Text('Titulo'),
         centerTitle: true,
         backgroundColor: const Color.fromARGB(255, 3, 67, 120),
      ),
      body: Center(
        child: Column(
           mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
          const Text('Bem vindo ao App Exame!',style:TextStyle(color: Colors.purple,fontSize: 24,fontWeight: FontWeight.bold)),
          ElevatedButton(style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
          ),
            onPressed: (){
              print('Botão pressionado com sucesso!');},
             child: const Text('Botão pro ex4 printando na tela do console')),





             ElevatedButton(style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
          ),
            onPressed: (){
                        print("Clicked");
              Navigator.push(context,MaterialPageRoute(builder: (context) => const MyCustomForm()),
              );
              },
             child: const Text('Botão pro texto'))
          ],
  
        ),
      ),
    ),);
  }
}
