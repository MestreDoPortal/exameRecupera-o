package com.example.app_exame

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
